#include "KParser.h"

inline std::string KPascal::KParser::Factor(std::string MethodName)
{
	std::string LeftSide = "";
	std::string RightSide = "";
	if (token.value == "(")
	{
		NewRegister = true;
		lexer.getToken(token);
		LeftSide = Expression();
		if (token.value == ")")
		{
			NewRegister = true;
			lexer.getToken(token);
			RightSide = FactorPrime(MethodName);
			if (RightSide == " " && LeftSide != " ")
			{
				std::cout << "we found love" << std::endl;
				fout << "		mov " << registerArray.kRegisters[registerArray.currentRegisterIndex].RegisterName << ", " << LeftSide << std::endl;
				registerArray.kRegisters[registerArray.currentRegisterIndex].IsUsed = true;
				registerArray.currentRegisterIndex++;
				NewRegister = false;
				return " ";
			}
			else if (RightSide == "*" && LeftSide == " ")
			{
				fout << "		imul " << registerArray.kRegisters[registerArray.currentRegisterIndex - 2].RegisterName << ", " << registerArray.kRegisters[registerArray.currentRegisterIndex - 1].RegisterName << std::endl;
				registerArray.kRegisters[registerArray.currentRegisterIndex - 1].IsUsed = false;
				registerArray.currentRegisterIndex--;
				return " ";
			}
		}
		else { HasError(token.value); }
	}
	else if (token.sType == "real" || token.sType == "integer")
	{
		std::string ReturnString = token.value;
		lexer.getToken(token);
		LeftSide = FactorPrime(MethodName);
		if (LeftSide == " ")
		{
			return ReturnString;
		}
		else if (LeftSide == "*")
		{
			fout << "		imul " << registerArray.kRegisters[registerArray.currentRegisterIndex - 1].RegisterName << ", " << ReturnString << std::endl;
			return " ";
		}
	}
	else if (token.sType == "word" && !token.isKeyword)
	{
		Token ReturnToken = token;
		std::string ReturnString = " ";
		// we only have global variables so far so this will be good enough 
		if (symbol.Table.find(ReturnToken.value) != symbol.Table.end())
		{
			ReturnString = "[ebp + " + std::to_string(symbol.Table[ReturnToken.value].offset) + "]";
		}
		lexer.getToken(token);
		LeftSide = FactorPrime(MethodName);
		if (LeftSide == " ") { return ReturnString; }
		else if (LeftSide == "*")
		{
			fout << "		imul " << registerArray.kRegisters[registerArray.currentRegisterIndex - 1].RegisterName << ", " << ReturnString << std::endl;
			return " ";
		}
	}
	else { HasError(token.value); }
	return " ";
}
