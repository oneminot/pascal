#ifndef LocalVariable_H_
#define LocalVariable_H_
#include <string>
#include "Variable.h"
namespace KPascal
{
	struct LocalVariable : Variable
	{
	};
}
#endif // !LocalVariable_H_
