﻿//#include "KParser.h"
//
//int main()
//{
//	KPascal::KParser parser;
//
//	parser.lexer.getToken(parser.token);
//	parser.program();
//	std::cout << "Good code. Press ENTER to quit." << std::endl;
//	std::cin.get();
//	return 0;
//}